<!DOCTYPE html PUBLIC>
<html xmlns="https://cosmosarchitecture.com/XHTML">
    <head>
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>COT - Cosmos Architecture</title>
        <link rel="stylesheet" href="../css-project/project.css">
        <link rel="stylesheet" href="../../../css/mobile.css">
        <link rel="stylesheet" href="../../../css/footer.css">
        <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>
        <link rel="stylesheet" href="../css/lightbox.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="../js/lightbox-plus-jquery.min.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="?family=https://fonts.googleapis.com/cssPoppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/1030d32312.js" crossorigin="anonymous"></script>
    </head>
    <body>
      <header>
  <div class="socinsta">
      <ul>

          <?php include '../../../functions/getSocialMediaLinks.php'; ?>
          <?php include '../../../functions/getMenuItems.php'; ?>
          <li><a href='<?php echo getSocialMediaLink("instagram", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                               style="width: 20px; height: 20px; margin-top: 5.7px; margin-left: 0px;"
                                                                                                               src="../../../dashboard/icons/instagram-logo.png"></a>
          </li>
          <li><a href='<?php echo getSocialMediaLink("twitter", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                             style="width: 20px; height: 20px; margin-top: 5.7px; margin-left: 0px;"
                                                                                                             src="../../../dashboard/icons/twitter-logo.png"></a>
          </li>
          <li><a href='<?php echo getSocialMediaLink("facebook", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                              style="width:20px; height: 20px; margin-top: 6px; margin-left: 0px;"
                                                                                                              src="../../../dashboard/icons/facebook-logo.png"></a>
          </li>
          <li><a href='<?php echo getSocialMediaLink("linkedin", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                              style="width: 20px; height: 20px; margin-top: 6px; margin-left: 0px;"
                                                                                                              src="../../../dashboard/icons/linkedin-logo.png"></a>
          </li>
      </ul>
  </div>


  <a href="../../../home.php"><img style="height: 10vh; width: auto;" src="../../../dashboard/icons/logo.png" class="logo"></a>

  <div class="menu">
    <nav>
        <div class="nav-lns" id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul class="test">
                <li><a href="../../project.php"><?php echo getMenuItems("1", "../../../files/menu-items.txt") ?></a>
                </li>

                <li>
                    <a href="../../en/estudio-en.php"><?php echo getMenuItems("2", "../../../files/menu-items.txt") ?></a>
                </li>
                <li>
                    <a href="../../contacto.php"><?php echo getMenuItems("3", "../../../files/menu-items.txt") ?></a>
                </li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
  </div>

</header>


<!--           NEW           -->
<section class="container" style="background-image: url(../../../images/img-project/arc/1/COT_01.jpg);">

  <div class="txt">
    <h1>COT_VIVIENDA UNIFAMILIAR <br><span>EN EL RETIRO</h1>
      <p style="font-size: 12px;">The region where this project is located stands out for preserving a very traditional aesthetic in its constructions. Moreover, our client wanted for his house to maintain the old traditions. Nevertheless, a contemporary influence was also added to the aesthetics. In addition, the project lot has a beautiful and abundant natural environment, which should be highlighted through the design.<br><br>
Taking these conditions into account, we developed a design of a house with ample proportions, but with an austere aesthetic, typical of the region. The shape of the house is divided into two main volumes with gabled roofs. The first volume contains the social spaces and the second the private ones, both are linked by corridors that run along the house accompanied by interior patios that emphasize the value of the natural environment within the project, which allows permanent contact with vegetation. <br><br>On the other hand, the visuals of all the rooms of the house are oriented towards a near forest and have a distant view of surrounding mountains.
Both, the orientation of the spaces and the distribution, as well as the volume of the house and the choice of materials, pay tribute not only to the construction tradition of the region, but also to its natural context. The warmth, austerity, simplicity of the materials and formal gestures of the house allow the natural environment and the life that takes place inside to always be the protagonists of the project.

</p>
  </div>




</section>

<section class="gallery">
  <a href="../../../images/img-project/arc/1/COT_01.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/1/COT_01.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/1/COT_02.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/1/COT_02.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/1/COT_03.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/1/COT_03.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/1/COT_04.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/1/COT_04.jpg" alt=""></a>




</section>


<section class="people">
  <div class="text">

    <h3>Location:</h3>

    <p>El Retiro, Antioquia, Colombia</p>

    <h3>Area:</h3>

    <p>550m2</p>


    <h3>Collaborating Architects:</h3>

    <p>Tomás Villa Arango</p>
    <p>Juan Martínez Zafra </p>
    <p>David Sastre Mata</p>
    <p>Pietro Paolo Speziale</p>

    <h3>External Collaborators:</h3>

    <p>-</p>

    <h3>Rendering:</h3>

    <p>Tomás Villa Arango</p>
  </div>

</section>


<section class="location">


<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15870.062381550202!2d-75.51133723368544!3d6.060975767627636!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e469ad88b01875b%3A0xf6fb1427cd59ffb0!2sEl%20Retiro%2C%20Retiro%2C%20Dipartimento%20di%20Antioquia%2C%20Colombia!5e0!3m2!1sit!2sit!4v1664652489253!5m2!1sit!2sit" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

</section>


<section class="container_btn">
  <div class="center_btn">
    <a href="../../project.php"><button>All Projects</button></a>
  </div>
</section>










<!-- WARNING


  <div class="container_btn">
  <div class="center_btn">
    <a href="../pages/project.php"><button>All Project</button></a>
  </div>
</div> -->



  <div class="footer-basic" style="margin-top: 0 !important">
      <footer>

          <div style="text-align: center; margin-bottom: 29px">
              <a href="../../../home.php"><img style="height: 10vh; width: auto;" src="../../../dashboard/icons/logo.png" alt="company logo"></a>
          </div>
          <ul class="list-inline">
              <li class="list-inline-item"><a href="../en/terms-of-use-en.php" target="_blank">Terms of use</a></li>
              <li class="list-inline-item"><a href="../en/privacy-cookie-policy-en.php" target="_blank">Privacy & Cookies Policy</a></li>
              <li class="list-inline-item"><a href="../en/credits-en.php" target="_blank">Credits</a></li>
              <li class="list-inline-item"><a href="../en/all-rights-reserved-en.php" target="_blank">All Rights Reserved</a></li>
          </ul>
      </footer>
  </div>







        <script>


        var navLinks = document.getElementById("navLinks");
        function showMenu(){
            navLinks.style.left="0";
        }
        function hideMenu(){
            navLinks.style.left="-200px";
        }



        // Get the modal
var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}


            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.left="0";
            }
            function hideMenu(){
                navLinks.style.left="-200px";
            }
            ScrollReveal().reveal('.headline', { distance: '100px',duration: 1500,interval: 400 } );


            var modal = document.getElementById("myModal");


var img = document.getElementById("myImg");
var img2 = document.getElementById("myImg2");
var img3 = document.getElementById("myImg3");
var img4 = document.getElementById("myImg4");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

img2.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}
img3.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}
img4.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}


var span = document.getElementsByClassName("close")[0];


span.onclick = function() {
  modal.style.display = "none";
}




        </script>
    </body>
</html>
