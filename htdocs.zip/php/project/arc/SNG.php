<!DOCTYPE html PUBLIC>
<html xmlns="https://cosmosarchitecture.com/XHTML">
    <head>
        <meta name="viewport" content="width=device-width,initial-scale=1.0">
        <title>SNG - Cosmos Architecture</title>
        <link rel="stylesheet" href="../css-project/project.css">
        <link rel="stylesheet" href="../../../css/mobile.css">
        <link rel="stylesheet" href="../../../css/footer.css">
        <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>
        <link rel="stylesheet" href="../css/lightbox.min.css">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="../js/lightbox-plus-jquery.min.js"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="?family=https://fonts.googleapis.com/cssPoppins:wght@100;200;300;400;600;700&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/1030d32312.js" crossorigin="anonymous"></script>
    </head>
    <body>
      <header>
  <div class="socinsta">
      <ul>

          <?php include '../../../functions/getSocialMediaLinks.php'; ?>
          <?php include '../../../functions/getMenuItems.php'; ?>
          <li><a href='<?php echo getSocialMediaLink("instagram", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                               style="width: 20px; height: 20px; margin-top: 5.7px; margin-left: 0px;"
                                                                                                               src="../../../dashboard/icons/instagram-logo.png"></a>
          </li>
          <li><a href='<?php echo getSocialMediaLink("twitter", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                             style="width: 20px; height: 20px; margin-top: 5.7px; margin-left: 0px;"
                                                                                                             src="../../../dashboard/icons/twitter-logo.png"></a>
          </li>
          <li><a href='<?php echo getSocialMediaLink("facebook", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                              style="width:20px; height: 20px; margin-top: 6px; margin-left: 0px;"
                                                                                                              src="../../../dashboard/icons/facebook-logo.png"></a>
          </li>
          <li><a href='<?php echo getSocialMediaLink("linkedin", "../../../files/social-media-links.txt"); ?>'><img alt
                                                                                                              style="width: 20px; height: 20px; margin-top: 6px; margin-left: 0px;"
                                                                                                              src="../../../dashboard/icons/linkedin-logo.png"></a>
          </li>
      </ul>
  </div>


  <a href="../../../home.php"><img style="height: 10vh; width: auto;" src="../../../dashboard/icons/logo.png" class="logo"></a>

  <div class="menu">
    <nav>
        <div class="nav-lns" id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>
            <ul class="test">
                <li><a href="../../project.php"><?php echo getMenuItems("1", "../../../files/menu-items.txt") ?></a>
                </li>

                <li>
                    <a href="../../en/estudio-en.php"><?php echo getMenuItems("2", "../../../files/menu-items.txt") ?></a>
                </li>
                <li>
                    <a href="../../contacto.php"><?php echo getMenuItems("3", "../../../files/menu-items.txt") ?></a>
                </li>
            </ul>
        </div>
        <i class="fa fa-bars" onclick="showMenu()"></i>
    </nav>
  </div>

</header>


<!--           NEW           -->
<section class="container" style="background-image: url(../../../images/img-project/arc/8/SNG_02.jpg);">

  <div class="txt">
    <h1>SNG_VIVIENDA UNIFAMILIAR <br><span> EN SAINT LOUIS</h1>
      <p style="font-size: 12px;">The patio is frequently disposed like a zone with multiple utilities, it can be a leisure zone patio and an air circulating space too, it is a very shapable place. Maybe that is why it appears in various forms in our architecture, regardless of its placement or form, it is simply a space that can contain many features. A patio house is a type of architecture that originated in ancient times. This concept of outdoors space joined housing is one of the main pieces of our architecture
The project is located in a privileged environment, between the dunes of the Atlantic Ocean and the Senegal river. <br><br>It is a unique combination of environments (mangroves, sand dunes, the Senegal River, the
Langue de Barbarie, tidal wetlands, the beach and the ocean). The Parc National de la Langue de Barbarie (Langue de Barbarie National Park) was established on January 9th, 1976. The park was created for the protection of important sea turtle nesting sites and is also an important migratory bird sanctuary. it has a rich and varied ecosystem.<br><br>
The house is located a few meters away from the Senegal River. It is a quiet, low-density area, where it has been sought to respect the aesthetic and urban parameters of the nearest homes, always seeking the maximum possible integration with the environment.
Materials without great luxuries give warmth to the space, we have searched for it to have a more conceptual and contemporary image.
This large patio has a more private character and is made up of an elongated infinity pool, different terraces and an outdoor dining area. With this patio, the living room, dining room and the master bedroom have privileged views of the beach.


</p>
  </div>




</section>

<section class="gallery">

  <a href="../../../images/img-project/arc/8/SNG_01.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_01.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/8/SNG_02.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_02.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/8/SNG_03.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_03.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/8/SNG_04.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_04.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/8/SNG_05.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_05.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/8/SNG_06.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_06.jpg" alt=""></a>
  <a href="../../../images/img-project/arc/8/SNG_07.jpg" data-lightbox="mygallery"><img src="../../../images/img-project/arc/8/SNG_07.jpg" alt=""></a>







</section>


<section class="people" >
  <div class="text">


    <h3>Location:</h3>
    <p>Saint Louis, Senegal</p>

    <h3>Area:</h3>
    <p>790m2</p>

    <h3>Collaborating Architects:</h3>

    <p>Tomás Villa Arango</p>
    <p>Juan Martínez Zafra </p>
    <p>David Sastre Mata</p>
    <p>Pietro Paolo Speziale</p>
    <p>Abdouraman Faye</p>


    <h3>External Collaborators:</h3>

    <p>-</p>

    <h3>Rendering:</h3>

    <p>Abellan.arq</p>
  </div>

</section>


<section class="location">

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d122715.96498726688!2d-16.593592238619546!3d16.020078203607202!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xe955655141ee805%3A0xe91d1d12f36a7e64!2sSaint-Louis%2C%20Senegal!5e0!3m2!1sit!2sit!4v1664816884618!5m2!1sit!2sit"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

</section>


<section class="container_btn">
  <div class="center_btn">
    <a href="../../project.php"><button>All Projects</button></a>
  </div>
</section>










<!-- WARNING


  <div class="container_btn">
  <div class="center_btn">
    <a href="../pages/project.php"><button>All Project</button></a>
  </div>
</div> -->



  <div class="footer-basic" style="margin-top: 0 !important">
      <footer>

          <div style="text-align: center; margin-bottom: 29px">
              <a href="../../../home.php"><img style="height: 10vh; width: auto;" src="../../../dashboard/icons/logo.png" alt="company logo"></a>
          </div>
          <ul class="list-inline">
              <li class="list-inline-item"><a href="../en/terms-of-use-en.php" target="_blank">Terms of use</a></li>
              <li class="list-inline-item"><a href="../en/privacy-cookie-policy-en.php" target="_blank">Privacy & Cookies Policy</a></li>
              <li class="list-inline-item"><a href="../en/credits-en.php" target="_blank">Credits</a></li>
              <li class="list-inline-item"><a href="../en/all-rights-reserved-en.php" target="_blank">All Rights Reserved</a></li>
          </ul>
      </footer>
  </div>







        <script>


        var navLinks = document.getElementById("navLinks");
        function showMenu(){
            navLinks.style.left="0";
        }
        function hideMenu(){
            navLinks.style.left="-200px";
        }



        // Get the modal
var modal = document.getElementById("myModal");

// Get the image and insert it inside the modal - use its "alt" text as a caption
var img = document.getElementById("myImg");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}


            var navLinks = document.getElementById("navLinks");
            function showMenu(){
                navLinks.style.left="0";
            }
            function hideMenu(){
                navLinks.style.left="-200px";
            }
            ScrollReveal().reveal('.headline', { distance: '100px',duration: 1500,interval: 400 } );


            var modal = document.getElementById("myModal");


var img = document.getElementById("myImg");
var img2 = document.getElementById("myImg2");
var img3 = document.getElementById("myImg3");
var img4 = document.getElementById("myImg4");
var modalImg = document.getElementById("img01");
var captionText = document.getElementById("caption");
img.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}

img2.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}
img3.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}
img4.onclick = function(){
  modal.style.display = "block";
  modalImg.src = this.src;
  captionText.innerHTML = this.alt;
}


var span = document.getElementsByClassName("close")[0];


span.onclick = function() {
  modal.style.display = "none";
}




        </script>
    </body>
</html>
