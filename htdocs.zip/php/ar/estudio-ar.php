<!DOCTYPE html PUBLIC>
<html>
<!--<html xmlns="https://cosmosarchitecture.com/XHTML">-->
<head>
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>مكتب - Cosmos Architecture</title>
    <html dir="ltr" lang="ar">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <script src="https://unpkg.com/scrollreveal@4.0.0/dist/scrollreveal.min.js"></script>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href="?family=https://fonts.googleapis.com/cssPoppins:wght@100;200;300;400;600;700&display=swap"
          rel="stylesheet">
          <script src="https://kit.fontawesome.com/1030d32312.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../../css/estudio.css">
    <link rel="stylesheet" href="../../css/mobile.css">
    <link rel="stylesheet" href="../../css/footer.css">

    <link rel="icon" type="image/x-icon" href="../../images/favicon.ico">
</head>
<body>
<header>


        <?php include '../../functions/getMenuItems.php'; ?>
        <?php include '../../functions/getSocialMediaLinks.php'; ?>
        <section class="head">
          <div class="social">



              <ul>
                  <li><a href='<?php echo getSocialMediaLink("instagram", "../../files/social-media-links.txt"); ?>' target="_blank"><img alt
                                                                                                                          style="width: 20px; height: 20px; "
                                                                                                                          src="../../dashboard/icons/instagram-logo.png"></a>
                  </li>
                  <li><a href='<?php echo getSocialMediaLink("twitter", "../../files/social-media-links.txt"); ?>' target="_blank"><img alt
                                                                                                                        style="width: 20px; height: 20px; "
                                                                                                                        src="../../dashboard/icons/twitter-logo.png"></a>
                  </li>
                  <li><a href='<?php echo getSocialMediaLink("facebook", "../../files/social-media-links.txt"); ?>' target="
                    "><img alt
                                                                                                                         style="width: 20px; height: 20px;"
                                                                                                                         src="../../dashboard/icons/facebook-logo.png"></a>
                  </li>
                  <li><a href='<?php echo getSocialMediaLink("linkedin", "../../files/social-media-links.txt"); ?>' target="_blank"><img alt
                                                                                                                         style="width: 20px; height: 20px; "
                                                                                                                         src="../../dashboard/icons/linkedin-logo.png"></a>
                  </li>
                </ul>

          </div>

          <div class="lingue">
            <ul >
                          <li><a href="../en/estudio-en.php"  class="no-active"><!-- <img alt
                                                                  style="width: 15px; height: 15px; margin-top: 6px; margin-left: 0px;"
                                                                  src="../../images/img-flags/flag-of-United-Kingdom.png">-->EN</a>
                          </li>
                          <li><a href="../esp/estudio-esp.php"  class="no-active"><!-- <img alt
                                                                    style="width:15px; height: 15px; margin-top: 6px; margin-left: 0px;"
                                                                    src="../../images/img-flags/flag-of-Spain.png">--> ES</a>
                          </li>
                          <li><a href="../it/estudio-it.php"  class="no-active"><!-- <img alt
                                               style="width: 15px; height: 15px; margin-top: 6px; margin-left: 0px; border-radius: 10px"
                                               src="../../images/img-flags/flag-of-Italy.png">--> IT</a>
                          </li>
                          <li><a href="../ch/estudio-ch.php"  class="no-active"><!-- <img alt
                                                                  style="width: 15px; height: 15px; margin-top: 6px; margin-left: 0;"
                                                                  src="../../images/img-flags/flag-of-China.png">--> CH</a>
                          </li>
                          <li><a href="#"><!-- <img alt
                                                                  style="width: 15px; height: 15px; margin-top: 6px; margin-left: 0;"
                                                                  src="../../images/img-flags/flag-of-Arabia.png">--> AR</a>
                          </li>
                        </ul>
          </div>

        </section>
    <a href="../../home.php"><img style="height: 10vh; width: auto;" src="../../dashboard/icons/logo.png"
                                                                                              class="logo"></a>
    <div class="menu">
      <nav>
          <div class="nav-lns" id="navLinks">
              <i class="fa fa-times" onclick="hideMenu()"></i>
              <ul>
                  <li><a href="../project.php"><?php echo getMenuItems("1", "../../files/menu-items.txt") ?></a></li>

                  <li><a href="../ar/estudio-ar.php"><?php echo getMenuItems("2", "../../files/menu-items.txt") ?></a>
                  </li>
                  <li><a href="../contacto.php"><?php echo getMenuItems("3", "../../files/menu-items.txt") ?></a></li>
              </ul>
          </div>
          <i class="fa fa-bars" onclick="showMenu()"></i>
      </nav>
    </div>
</header>
<div class="hero">

    <?php include '../../functions/getEstudioVideoInforamtion.php' ?>


    <video autoplay muted loop >
      <source src="../../estudio-video/video-estudio.mp4" type="video/mp4">
    </video>
</div>

<?php include '../../functions/getEstudioText.php' ?>

<section class="txt headline">

    <?php echo getEstudioText('../../files/ar/estudio-ar.txt') ?>

    <br><br>
    <h4 lang="ar" dir="rtl">اتصل بنا</h4>
</section>


<section class="row headline">


    <div class="campus-col">
        <div><img src="../../images/img-members/03_DAVID.png">

            <div class="layer">
                <ul>
                    <h3>DAVID SASTRE MATA</h3>
                    <p>Partner - Architect</p>
                    <a href="https://www.linkedin.com/in/david-sastre-mata-30884648/?originalSubdomain=es" class="linkedin"><i class="fa-brands fa-linkedin "></i></a>

                    <a href="mailto: david.sastre@cosmosarchitecture.com" class="email"><i class="fa-solid fa-envelope "></i></a>

                </ul>
            </div>
        </div>
    </div>
    <div class="campus-col">
        <div><img src="../../images/img-members/02_PIETRO.png">
            <div class="layer">
              <ul>
                  <h3>PIETRO PAOLO SPEZIALE</h3>
                  <p>Partner - Architect</p>
                  <a href="https://www.linkedin.com/in/pietropaolospeziale/" class="linkedin"><i class="fa-brands fa-linkedin "></i></a>

                  <a href="mailto: pietropaolo.speziale@cosmosarchitecture.com" class="email"><i class="fa-solid fa-envelope "></i></a>

              </ul>
            </div>
        </div>
    </div>

    <div class="campus-col">
        <div><img src="../../images/img-members/01_JUAN MARTINEZ.png">
            <div class="layer">
              <ul>
                  <h3>JUAN MARTÍNEZ ZAFRA</h3>
                  <p>Partner - Architect</p>
                  <a href="https://www.linkedin.com/in/juan-martinez-zafra/" class="linkedin"><i class="fa-brands fa-linkedin "></i></a>

                  <a href="mailto: juan.zafra@cosmosarchitecture.com" class="email"><i class="fa-solid fa-envelope "></i></a>

              </ul>
            </div>
        </div>
    </div>
    <div class="campus-col">
        <div><img src="../../images/img-members/04_TOMAS.png">
            <div class="layer">
              <ul>
                  <h3>TOMÁS VILLA ARANGO</h3>
                  <p>Partner - Architect</p>
                  <a href="https://www.linkedin.com/in/tomasvillaa/" class="linkedin"><i class="fa-brands fa-linkedin "></i></a>

                  <a href="mailto: tomas.villa@cosmosarchitecture.com" class="email"><i class="fa-solid fa-envelope "></i></a>

              </ul>
            </div>
        </div>
    </div>
</section>

<br><br>

<!-- WARNING -->

<script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-df1e1e09-00f8-49af-85b8-914b1f72839c"></div>

<script>
    var navLinks = document.getElementById("navLinks");

    function showMenu() {
        navLinks.style.left = "0";
    }

    function hideMenu() {
        navLinks.style.left = "-200px";
    }

    ScrollReveal().reveal('.headline', {distance: '150px', duration: 1500, interval: 400});
</script>

<div class="footer-basic" style="margin-top: 0 !important">
    <footer>

        <div style="text-align: center; margin-bottom: 29px">
            <a href="../../home.php"><img style="height: 10vh; width: auto;" src="../../dashboard/icons/logo.svg" alt="company logo"></a>
        </div>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="../en/terms-of-use-en.php" target="_blank">Terms of use</a></li>
            <li class="list-inline-item"><a href="../en/privacy-cookie-policy-en.php" target="_blank">Privacy & Cookies Policy</a></li>
            <li class="list-inline-item"><a href="../en/credits-en.php" target="_blank">Credits</a></li>
            <li class="list-inline-item"><a href="../en/all-rights-reserved-en.php" target="_blank">All Rights Reserved</a></li>
        </ul>
    </footer>
</div>

</body>
</html>
