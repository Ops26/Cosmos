<!DOCTYPE html>
<!-- Created by CodingLab |www.youtube.com/CodingLabYT-->
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <title>COSMOS Dashboard</title>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/1030d32312.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="../css/dashboard-project.css">
    <!--    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"-->
    <!--          integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2"
            crossorigin="anonymous"></script>
    <!--    <link rel="stylesheet" href="../css/style.css">-->
    <!--    <link rel="stylesheet" href="../css/dashboard_old.css">-->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

</head>
<body>
<div class="sidebar">
    <div class="logo-details">
        <i class='bx bxl-c-plus-plus icon'></i>
        <div class="logo_name">COSMOS</div>
        <i class='bx bx-menu' id="btn"></i>
    </div>
    <ul class="nav-list">
        <li>
            <a href="dashboard-homepage.php">
                <i class='bx bx-book-content'></i>
                <span class="links_name">Homepage</span>
            </a>
            <span class="tooltip">Homepage</span>
        </li>
        <li>
            <a href="dashboard-newsletter.php">
                <i class='bx bx-news'></i>
                <span class="links_name">Newsletter</span>
            </a>
            <span class="tooltip">Newsletter</span>
        </li>
        <li>
            <a href="dashboard-contacto.php">
                <i class='bx bxs-chat'></i>
                <span class="links_name">Contacto</span>
            </a>
            <span class="tooltip">Contacto</span>
        </li>
        <li>
            <a href="dashboard-estudio.php">
                <i class='bx bx-male'></i>
                <span class="links_name">Estudio</span>
            </a>
            <span class="tooltip">Estudio</span>
        </li>

        <li>
            <a href="#">
                <i class="fa-solid fa-diagram-project"></i>
                <span class="links_name">Project</span>
            </a>
            <span class="tooltip">Project</span>
        </li>


        <li>
            <p>
                &nbsp
            </p>
        </li>
        <li>
            <a href="dashboard-terms-of-use.php">
                <i class='bx bx-columns'></i>
                <span class="links_name">Terms of use</span>
            </a>
            <span class="tooltip">Terms of use</span>
        </li>
        <li>
            <a href="dashboard-privacy-cookie-policy.php">
                <i class='bx bx-cookie'></i>
                <span class="links_name">Privacy & Cookies Policy</span>
            </a>
            <span class="tooltip">Privacy & Cookies Policy</span>
        </li>
        <li>
            <a href="dashboard-credits.php">
                <i class='bx bxs-face'></i>
                <span class="links_name">Credits</span>
            </a>
            <span class="tooltip">Credits</span>
        </li>
        <li>
            <a href="dashboard-all-rights-reserved.php">
                <i class='bx bx-check'></i>
                <span class="links_name">All Rights Reserved</span>
            </a>
            <span class="tooltip">All Rights Reserved</span>
        </li>
    </ul>
</div>





<!--page start-->

<section class="home-section">
    <div class="text">Dashboard - Project</div>
    <!--    ⌝⌝⌝⌝⌝⌝⌝⌝⌝-->

    <BR>

<?php
      $path = "../php/project/";
      $pathEnding = "php";

      foreach (glob('../php/project/*.php') as $filename) {
          $p = pathinfo($filename);

      }
          ?>


    <div class="btn_1">
      <a href=""><button onclick="copy()">New Project</button></a>
    </div>

    <br><br>

    <div class="rename">
    <p>Rename the new file:</p>
    <input style="width: 250px" id="imageName" value="<?php echo str_replace('ÜÜ', '/', $p['filename']) ?>"
           onblur='renameFile("<?php echo str_replace('/', 'ÜÜ', $p['filename']) ?>",
                   this.value.replace(/^https?:\/\//, "").replace(/^http?:\/\//, "").replaceAll("/", "ÜÜ"))'>

        </div>

        <p>Rename the new dashboard file (Put the name the same as that of the new file):</p>
        <input style="width: 250px" id="DashboardName" value="<?php echo str_replace('ÜÜ', '/', $p['filename']) ?>"
               onblur='renameFiledashboard("<?php echo str_replace('/', 'ÜÜ', $p['filename']) ?>",
                       this.value.replace(/^https?:\/\//, "").replace(/^http?:\/\//, "").replaceAll("/", "ÜÜ"))'>

            </div>


    <br>
    <br>

    <div class="title"><h1>All Project:</h1></div>

    <br><br><br>

<div class="all_file">
    <?php

    $fileList = glob('../php/project/*.php');
    foreach($fileList as $filename){
    if(is_file($filename)){
        echo $filename, '<br><br><br>';
    }
  }
?>

<div class="dropdown">
  <button class="dropbtn">View Dashboard</button>
  <div class="dropdown-content">
    <?php

    $fileList = glob('../php/project/dashboard/*.php');
    foreach($fileList as $filename){
    if(is_file($filename)){
        echo "<a href=../dashboard/$filename>".$filename.'</a>';
    }
  }
?>


  </div>
</div>


</div>

<br><br><br>

    <div class="upload_file">

      <p id="addNewProject" style="margin-left: 40px; margin-top: 13px; font-size: 25px">Add New File</p>

      <form action="../functions/upload-file-project.php" method="post" enctype="multipart/form-data">
          <div class="fileInput" style="text-align: left;">
              <input class="chooseFileLabel" type="file" name="fileToUpload" id="fileToUpload"
                     accept="file/php">
          </div>

          <BR>

          <div class="linkInput">
              <label for="linkForImage"></label>
              <input type="text" id="linkForImage" name="link" placeholder="Add Link" size="30px"
                     style="border-color: gray; height: 30px">
              <p style="font-size: 14px">upload only php file</p>
          </div>

          <div style="text-align: right; margin-right: 20px">
              <button class="uploadImageButton" type="submit" name="submit" role="button"
                      style="background-color: #06f;">Upload File
              </button>
          </div>

    </div>
</section>





<!--page end-->

<script>


function renameFile(oldFileName, newFilename) {

    if (newFilename === "") {
        alert("The link can not be empty!");
        window.location.reload();
        return;
    } else if (newFilename === oldFileName) {
        return;
    }

    $.ajax({
        url: "../functions/renameFile.php",
        type: "POST",
        data: {functionCall: "renameFile", oldImageName: oldFileName, newImageName: newFilename},
        success: function (result) {
            // window.localStorage.clear();
            window.location.reload();
        }
    });
}



function renameFiledashboard(oldDashboardName, newDashboardName) {

    if (newDashboardName === "") {
        alert("The link can not be empty!");
        window.location.reload();
        return;
    } else if (newDashboardName === oldDashboardName) {
        return;
    }

    $.ajax({
        url: "../functions/renameFiledashboard.php",
        type: "POST",
        data: {functionCall: "renameFiledashboard", oldDashName: oldDashboardName, newDashName: newDashboardName},
        success: function (result) {
            // window.localStorage.clear();
            window.location.reload();
        }
    });
}






function copy() {
      $.ajax({
           type: "POST",
           url: '../functions/copy_file.php',
           data:{action:'call_this'},
           success:function(html) {
             alert(html);
           }

      });
 }






    let sidebar = document.querySelector(".sidebar");
    let closeBtn = document.querySelector("#btn");
    let searchBtn = document.querySelector(".bx-search");

    closeBtn.addEventListener("click", () => {
        sidebar.classList.toggle("open");
        menuBtnChange();
    });

    function menuBtnChange() {
        if (sidebar.classList.contains("open")) {
            closeBtn.classList.replace("bx-menu", "bx-menu-alt-right");
        } else {
            closeBtn.classList.replace("bx-menu-alt-right", "bx-menu");
        }
    }

</script>
</body>
</html>
